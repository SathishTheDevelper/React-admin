import axios from "axios";

class API {
  constructor() {
    this.rootUrl = process.env.REACT_APP_API;
    this.header = { authorization: `Bearer ${localStorage.getItem("admin_token")}` };
    // crud service
    this.getAll = async (dispatch, action, url, params,callback) => {
      if (action[0]!=="") dispatch(action[0]);
      try {
        const res = await axios.get(this.rootUrl + url,{headers:this.header,params: params});
        if (action[1] !== "") dispatch(action[1](res.data));
        callback(null, res);
        return res;
      } catch (error) {
        if (action[2] !== "") dispatch(action[2]);
        callback(error, null);
        return error;
      }
    };

    this.getAllCommon = async (dispatch, action, url, params,callback) => {
      if (action[0]!=="") dispatch(action[0]);
      try {
        const res = await axios.get(url, { params: params });
        if (action[1] !== "") dispatch(action[1](res.data));
        callback(null, res);
        return res;
      } catch (error) {
        if (action[2] !== "") dispatch(action[2]);
        callback(error, null);
        return error;
      }
    };

    this.getSingle = async (dispatch, action, url, params, callback) => {
      if (action[0] !== "") dispatch(action[0]);
      try {
        const res = await axios.get(`${this.rootUrl + url}/${params}`,{headers:this.header});
        if (action[1] !== "") dispatch(action[1](res.data));
        callback(null, res);
        return res;
      } catch (error) {
        if (action[2] !== "") dispatch(action[2]);
        callback(error, null);
        return error;
      }
    };

    this.create = async (dispatch, action, url, data, callback) => {
      if (action[0] !== "") dispatch(action[0]);
      try {
        const res = await axios.post(this.rootUrl + url, data,{headers:this.header});
        if (action[1] !== "") dispatch(action[1](res.data));
        callback(null, res);
        return res;
      } catch (error) {
        if (action[2] !== "") dispatch(action[2]);
        callback(error, null);
        return error;
      }
    };

    this.createCommon = async (dispatch, action, url, data, callback) => {
      if (action[0] !== "") dispatch(action[0]);
      try {
        const res = await axios.post(url, data,{headers:this.header});
        if (action[1] !== "") dispatch(action[1](res.data));
        callback(null, res);
        return res;
      } catch (error) {
        if (action[2] !== "") dispatch(action[2]);
        callback(error, null);
        return error;
      }
    };

    this.update = async (dispatch, action, url, params, data, callback) => {
      if (action[0] !== "") dispatch(action[0]);
      try {
        const res = await axios.put(`${this.rootUrl + url}/${params}`, data,{headers:this.header});
        if (action[1] !== "") dispatch(action[1](res.data));
        callback(null, res);
        return res;
      } catch (error) {
        if (action[2] !== "") dispatch(action[2]);
        callback(error, null);
        return error;
      }
    };

    this.remove = async (dispatch, action, url, params, callback) => {
      if (action[0] !== "") dispatch(action[0]);
      try {
        const res = await axios.delete(`${this.rootUrl + url}/${params}`,{headers:this.header});
        if (action[1] !== "") dispatch(action[1](res.data));
        callback(null, res);
        return res;
      } catch (error) {
        if (action[2] !== "") dispatch(action[2]);
        callback(error, null);
        return error;
      }
    };
  }
}

export default API;
