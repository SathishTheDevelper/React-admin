import React from 'react'
import Country from './../Component/Country';
import State from "./../Component/State";
import Home from '../Component/Home';
;
const authRoute = [
  {
    index: true,
    exact: true,
    path: "/",
    element: <Home title="Dashboard" />,
  },
  {
    exact: true,
    path: "/country",
    element: <Country title="Country" />,
  },
  {
    exact: true,
    path: "/state",
    element: <State title="State" />,
  },
];






export { authRoute };