import React,{useEffect} from 'react'
import Dashboard from './Component/Dashboard';
import Login from './Component/Login';

const App = () => {
  const token = localStorage.getItem("admin_token");
  const login_true = localStorage.getItem("is_admin");
  useEffect(() => {}, [token, login_true]);
  return (
    <>
      {token !== "" && Boolean(login_true) === true ? <Dashboard /> : <Login />}
    </>
  );
}

export default App;