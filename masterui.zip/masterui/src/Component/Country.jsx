import React, { useState } from "react";
import { Button, Popconfirm, Input, Form, Modal, message } from "antd";
import { TableService, Status } from "../Api/TableService";
import TableDynamic from "../Api/TableDynamic";
import BreadcrumbDynamic from "../Api/BreadcrumbDynamic";
import {countryListStart, countryListSuccess, countryListFailure,countrySingleStart,countrySingleSuccess,countrySingleFailure} from '../Redux/Slice/CountrySlice'
import {
  PlusCircleOutlined,
  EditOutlined,
  DeleteOutlined,
} from "@ant-design/icons";
import { useEffect } from "react";
import AddCountry from "../Forms/AddCountry";
import API from '../Api/ApiService';
import { useSelector,useDispatch } from "react-redux";
import EditCountry from "../Forms/EditCountry";
const Country = ({ title }) => {
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loadingCreate, setLoadingCreate] = useState(false);
  const [loadingEdit, setLoadingEdit] = useState(false);
  const [openCreate, setOpenCreate] = useState(false);
  const [openEdit, setOpenEdit] = useState(false);
  const [formCreate] = Form.useForm();
  const [formEdit] = Form.useForm();
  const dispatch = useDispatch();
  const onSelectChange = (newSelectedRowKeys) => {
    setSelectedRowKeys(newSelectedRowKeys);
  };
  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
  };
  const api = new API();
  //popup
  const openPopup = (type) => {
    // eslint-disable-next-line default-case
    switch (type) {
      case "create":
        return setOpenCreate(true);
      case "edit":
        return setOpenEdit(true);
    }
  };
  const closePopup = (type) => {
    // eslint-disable-next-line default-case
    switch (type) {
      case "create":
        return setOpenCreate(false);
      case "edit":
        return setOpenEdit(false);
    }
  };

  const columns = [
    {
      title: "Country Name",
      dataIndex: "name",
      ...TableService("name"),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: Status("status"),
    },
    {
      title: "Action",
      dataIndex: "action",
      render: (action) => (
        <div className="action_btn_table">
          <p className=" edit" onClick={() => getSingleAction(action)}>
            <EditOutlined />
          </p>
          <Popconfirm
            title=" Are you Sure to delete?"
            onConfirm={() => deleteAction(action)}
            okButtonProps={{
              loading: deleteLoading,
            }}
          >
            <DeleteOutlined />
          </Popconfirm>
        </div>
      ),
    },
  ];
  const data = [];
  const country = useSelector((state) => state?.country?.countrylist?.data);
  const singlecountry = useSelector(
    (state) => state?.country?.countrysingle?.data
  );
  if (singlecountry) {
    formEdit.setFieldsValue(singlecountry);
  }
  country?.forEach((e) => {
    data.push({
      key: e._id ?? "",
      name: e.name ?? "",
      status: [e.status ?? ""],
      action: e._id ?? "",
    });
  });
  //search
  const handleSearch = (searchText) => {
    const keys = ["name"];
    const filtered = data.filter((item) =>
      keys.some((key) =>
        item[key].toLowerCase().includes(searchText.toLowerCase())
      )
    );
    setFilteredData(filtered);
  };

  //init function
  const initFunction = async () => {
    await api.getAll(
      dispatch,
      [countryListStart, countryListSuccess, countryListFailure],
      "mastersettings",
      { type: "country" },
      (err, res) => {
        setLoading(true);
        if (err) {
          setLoading(true);
        } else {
          setLoading(false);
        }
      }
    );
  };
  //init render
  useEffect(() => {
    initFunction();
  }, []);
  //create
  const createAction = async (values) => {
    setLoadingCreate(true);
    values["type"] = "country";
    await api.create(
      dispatch,
      ["", "", ""],
      "mastersettings",
      values,
      (err, res) => {
        if (err) {
          message.error(err?.response?.data?.message);
          setLoadingCreate(false);
        } else {
          message.success(res?.data?.message);
          formCreate.resetFields();
          initFunction();
          setOpenCreate(false);
          setLoadingCreate(false);
        }
      }
    );
  };
  //get signle
  const getSingleAction = async (action) => {
    setOpenEdit(true);
    await api.getSingle(
      dispatch,
      [countrySingleStart, countrySingleSuccess, countrySingleFailure],
      "mastersettings",
      action,
      (err, res) => {}
    );
  };
  //edit
  const editAction = async (values) => {
    setLoadingEdit(true);
    await api.update(
      dispatch,
      ["", "", ""],
      "mastersettings",
      singlecountry?._id,
      values,
      (err, res) => {
        if (err) {
          message.error(err?.response?.data?.message);
          setLoadingEdit(false);
        } else {
          message.success(res?.data?.message);
          setLoadingEdit(false);
          setOpenEdit(false);
          initFunction();
        }
      }
    );
  };
  //delete
  const deleteAction = async (action) => {
    await api.remove(
      dispatch,
      ["", "", ""],
      "mastersettings",
      action,
      (err, res) => {
        if (err) {
          message.error(err?.response?.data?.message);
        } else {
          message.success(res?.data?.message);
          initFunction();
        }
      }
    );
  };

  return (
    <>
      <BreadcrumbDynamic title={title} />
      <div className="bg_box p_20">
        <div className="action_head">
          <div className="action_head_left">
            <Input
              size="medium"
              placeholder="Search"
              className="width_230"
              onChange={(e) => handleSearch(e.target.value)}
            />
          </div>
          <div className="action_head_right">
            <Button
              type="primary"
              className="action_btn"
              onClick={() => openPopup("create")}
            >
              <PlusCircleOutlined /> Add
            </Button>
          </div>
        </div>
        <TableDynamic
          rowSelection={rowSelection}
          columns={columns}
          data={filteredData.length > 0 ? filteredData : data}
          loading={loading}
        />
      </div>
      <Modal
        title="Create"
        open={openCreate}
        footer={null}
        onCancel={() => closePopup("create")}
        width={450}
      >
        <Form layout="vertical" form={formCreate} onFinish={createAction}>
          <AddCountry />
          <Form.Item>
            <Button type="primary" htmlType="submit" loading={loadingCreate}>
              Create
            </Button>
          </Form.Item>
        </Form>
      </Modal>
      <Modal
        title="Edit"
        open={openEdit}
        footer={null}
        onCancel={() => closePopup("edit")}
        width={450}
      >
        <Form layout="vertical" form={formEdit} onFinish={editAction}>
          <EditCountry />
          <Form.Item>
            <Button type="primary" htmlType="submit" loading={loadingEdit}>
              Update
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};

export default Country