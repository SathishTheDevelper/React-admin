import React from "react";
import { Form, Select,Input, Switch } from "antd";
import { useSelector } from "react-redux";
import API from "../Api/ApiService";
import { useDispatch } from "react-redux";
import {
  stateApiStart,
  stateApiSuccess,
  stateApiFailure,
} from '../Redux/Slice/StateSlice'
  import {
    countryListStart,
    countryListSuccess,
    countryListFailure,
  } from "../Redux/Slice/CountrySlice";
import { useState,useEffect } from "react";

const AddState = () => {
  const list = [];
  let list_state = [];
  const api = new API();
  const [stateLoading, setStateLoading] = useState(false);
  const dispatch = useDispatch();
  const country = useSelector((state) => state?.country?.countrylist?.data);
  const state = useSelector((state) => state?.state?.stateapi?.data?.states);
  console.log("state", state);
  country?.forEach((e) => {
    list.push({
      label: e.name ?? "",
      value: e._id ?? ""
    });
  });
  state?.forEach((e) => {
    list_state.push({
      label: e.name??"",
      value: e.name??"",
    });
  });
  const countryList = async (e) => {
    console.log("e", e);
    list_state = [];
    setStateLoading(true);
    await api.createCommon(
      dispatch,
      [stateApiStart, stateApiSuccess, stateApiFailure],
      "https://countriesnow.space/api/v0.1/countries/states",
      { country: e },
      (err, res) => {
        setStateLoading(false);
      }
    );
  }
  //initFunction
  const initFunction = async () => {
    await api.getAll(
      dispatch,
      [countryListStart, countryListSuccess, countryListFailure],
      "mastersettings",
      { type: "country" },
      (err, res) => {
      }
    );
  }
  //init
  useEffect(() => {
    initFunction();
  },[])
  return (
    <>
      <Form.Item
        label="Choose Country"
        name="country"
        rules={[
          {
            required: true,
            message: "Country is required!",
          },
        ]}
      >
        <Select
          showSearch
          placeholder="Search to Select"
          optionFilterProp="children"
          onChange={(e) => countryList(e)}
          filterOption={(input, option) =>
            (option?.label ?? "").includes(input)
          }
          filterSort={(optionA, optionB) =>
            (optionA?.label ?? "")
              .toLowerCase()
              .localeCompare((optionB?.label ?? "").toLowerCase())
          }
          options={list}
        />
      </Form.Item>
      <Form.Item
        label="Choose State"
        name="name"
        rules={[
          {
            required: true,
            message: "State is required!",
          },
        ]}
      >
        <Input />
      </Form.Item>
      <Form.Item label="Status" name="status">
        <Switch defaultChecked />
      </Form.Item>
    </>
  );
};

export default AddState;
