import React from "react";
import { Form, Input, Switch } from "antd";

const EditCountry = () => {
  return (
    <>
      <Form.Item
        label="Choose Country"
        name="name"
        rules={[
          {
            required: true,
            message: "Country is required!",
          },
        ]}
      >
        <Input />
      </Form.Item>
      <Form.Item label="Status" name="status">
        <Switch defaultChecked />
      </Form.Item>
    </>
  );
};

export default EditCountry;
