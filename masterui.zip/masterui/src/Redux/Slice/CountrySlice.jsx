import { createSlice } from "@reduxjs/toolkit";

const countrySlice = createSlice({
  name: "country",
  initialState: {
    countrylist: null,
    countrysingle: null,
    countryapi: null,
    isFetching: false,
    error: false,
  },
  reducers: {
    countryListStart: (state) => {
      state.isFetching = true;
    },
    countryListSuccess: (state, action) => {
      state.isFetching = false;
      state.countrylist = action.payload;
    },
    countryListFailure: (state) => {
      state.isFetching = false;
      state.error = true;
    },
    countryApiStart: (state) => {
      state.isFetching = true;
    },
    countryApiSuccess: (state, action) => {
      state.isFetching = false;
      state.countryapi = action.payload;
    },
    countryApiFailure: (state) => {
      state.isFetching = false;
      state.error = true;
    },
    countrySingleStart: (state) => {
      state.isFetching = true;
    },
    countrySingleSuccess: (state, action) => {
      state.isFetching = false;
      state.countrysingle = action.payload;
    },
    countrySingleFailure: (state) => {
      state.isFetching = false;
      state.error = true;
    },
  },
});

export const {
  countryListStart,
  countryListSuccess,
  countryListFailure,
  countryApiStart,
  countryApiSuccess,
  countryApiFailure,
  countrySingleStart,
  countrySingleSuccess,
  countrySingleFailure,
} = countrySlice.actions;
export default countrySlice.reducer;
