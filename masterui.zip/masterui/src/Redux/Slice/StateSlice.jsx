import { createSlice } from "@reduxjs/toolkit";

const stateSlice = createSlice({
  name: "state",
  initialState: {
    statelist: null,
    statesingle: null,
    stateapi: null,
    isFetching: false,
    error: false,
  },
  reducers: {
    stateListStart: (state) => {
      state.isFetching = true;
    },
    stateListSuccess: (state, action) => {
      state.isFetching = false;
      state.statelist = action.payload;
    },
    stateListFailure: (state) => {
      state.isFetching = false;
      state.error = true;
    },
    stateApiStart: (state) => {
      state.isFetching = true;
    },
    stateApiSuccess: (state, action) => {
      state.isFetching = false;
      state.stateapi = action.payload;
    },
    stateApiFailure: (state) => {
      state.isFetching = false;
      state.error = true;
    },
    stateSingleStart: (state) => {
      state.isFetching = true;
    },
    stateSingleSuccess: (state, action) => {
      state.isFetching = false;
      state.statesingle = action.payload;
    },
    stateSingleFailure: (state) => {
      state.isFetching = false;
      state.error = true;
    },
  },
});

export const {
  stateListStart,
  stateListSuccess,
  stateListFailure,
  stateApiStart,
  stateApiSuccess,
  stateApiFailure,
  stateSingleStart,
  stateSingleSuccess,
  stateSingleFailure,
} = stateSlice.actions;
export default stateSlice.reducer;
