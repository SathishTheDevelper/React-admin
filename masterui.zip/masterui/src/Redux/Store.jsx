import { configureStore } from "@reduxjs/toolkit";
import adminSlice from "./Slice/LoginSlice";
import countrySlice from "./Slice/CountrySlice";
import stateSlice from "./Slice/StateSlice";

const Store = configureStore({
  reducer: {
    admin: adminSlice,
    country: countrySlice,
    state: stateSlice,
  },
});

export default Store;
